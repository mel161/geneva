// import {$,jQuery} from 'jquery';
// // export for others scripts to use
// window.$ = $;
// window.jQuery = jQuery;
// import {validate, validator} from 'jquery-validation'
// import 'jquery-validation/dist/additional-methods.js'
import Tinyfade from './vendor/tinyfade.min.js'
import MoveTo from 'moveto'
import VMasker from 'vanilla-masker'

function validateForms() {
  $('.form').each(function() {
    $(this).validate({
      errorClass: 'input__error',
      errorElement: 'span',
      messages: {
        phone: {
          checkMask: "Неверный формат номера"
        }
      },
      highlight: function(element, errorClass, validClass) {
        $(element).parent().removeClass('input--valid').addClass('input--error');
      },
      unhighlight: function(element, errorClass, validClass) {
        $(element).parent().removeClass('input--error').addClass('input--valid');
      }
    });
  });
}

jQuery.validator.addMethod("checkMask", function(value, element) {
  return /\+\d{1}\(\d{3}\)\d{3}-\d{2}-\d{2}/g.test(value);
});

jQuery.validator.setDefaults({
  debug: true
});

jQuery.extend(jQuery.validator.messages, {
  required: "Поле должно быть заполнено.",
  remote: "Please fix this field.",
  email: "Please enter a valid email address.",
  url: "Please enter a valid URL.",
  date: "Please enter a valid date.",
  dateISO: "Please enter a valid date (ISO).",
  number: "Please enter a valid number.",
  digits: "Please enter only digits.",
  creditcard: "Please enter a valid credit card number.",
  equalTo: "Please enter the same value again.",
  accept: "Please enter a value with a valid extension.",
  maxlength: jQuery.validator.format("Please enter no more than {0} characters."),
  minlength: jQuery.validator.format("Please enter at least {0} characters."),
  rangelength: jQuery.validator.format("Please enter a value between {0} and {1} characters long."),
  range: jQuery.validator.format("Please enter a value between {0} and {1}."),
  max: jQuery.validator.format("Please enter a value less than or equal to {0}."),
  min: jQuery.validator.format("Please enter a value greater than or equal to {0}.")
});

$(function() {
  $('input').focus(function() {
    $(this).parents('.form__block').addClass('focused');
  });

  $('input').blur(function() {
    var inputValue = $(this).val();
    if (inputValue == "") {
      $(this).removeClass('filled');
      $(this).parents('.form__block').removeClass('focused');
    } else {
      $(this).addClass('filled');
    }
  });

  validateForms();

  if (document.body.classList.contains('home')) {
    let tf = new Tinyfade(
      ".tinyfade", // Element
      5000, // Interval in milliseconds (-1 for manual mode, default = 5000)
      1500 // Animation duration (default = 1000)
    );

    var rafTimer;
    window.onscroll = function(event) {
      cancelAnimationFrame(rafTimer);
      rafTimer = requestAnimationFrame(toggleHeaderFloating);
    };

    var heroHeight = $(".header--hero").height();

    function toggleHeaderFloating() {
      if (window.scrollY > heroHeight) {
        document.body.classList.add('sticky');
      } else {
        document.body.classList.remove('sticky');
      }
    }
  }

  const moveTo = new MoveTo()
  const triggers = document.getElementsByClassName('js-moveto');

  for (var item of triggers) {
    moveTo.registerTrigger(item);
  }

  $('.input__field--phone').mask("+7(999)999-99-99");
});
