const config = {};

config.appPath = './app/';
config.sourcePath = `${config.appPath}src/`;
config.assetsPath = `${config.sourcePath}assets/`;
config.nodeModules = './node_modules/';
config.buildPath = `${config.appPath}build/`;

module.exports = config;
