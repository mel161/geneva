const config = require('./');

module.exports = {
    server: {
        baseDir: config.buildPath,
    },
    open: false,
};
