module.exports = require('./gulpfile.js/lib/webpack-multi-config')('development');
